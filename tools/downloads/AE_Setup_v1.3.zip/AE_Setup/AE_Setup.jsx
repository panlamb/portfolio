//@target aftereffects
/*
    AE Setup  v1.3  ·  After Effects script by Panos Lambrakis (panlamb.github.io/portfolio)

    One click after you import the files made by AI_to_AE_Prep (Illustrator).
    Works on the comps selected in the Project panel; with none selected, on the comp open in the viewer.

      1. Names: removes the "/file.ai" After Effects adds to every layer name.
      2. Blend modes: "glow [screen]" becomes a layer "glow" in Screen mode.
      3. Track mattes: links the M1, M2... pairs as Alpha Matte and hides the matte.
      4. Frame: crops the comp back to the frame stored in the "FRAME WxH @x,y" layer; nothing moves on screen.
      5. Anchor points: centred on each layer's content; nothing moves on screen.
      6. Project: the footage of each .ai goes into a folder named after its comp.

    Everything is one Undo (Ctrl+Z / Cmd+Z).
    Guide: AE_Setup_GUIDE.txt (next to this file).

    Free to use in personal and commercial projects. Please don't resell or re-upload it;
    link to panlamb.github.io/portfolio/tools/ instead.
*/
(function () {
    var SCRIPT_NAME = "AE Setup";

    var MODES = {
        "multiply": BlendingMode.MULTIPLY, "screen": BlendingMode.SCREEN, "overlay": BlendingMode.OVERLAY,
        "soft-light": BlendingMode.SOFT_LIGHT, "hard-light": BlendingMode.HARD_LIGHT,
        "color-dodge": BlendingMode.COLOR_DODGE, "color-burn": BlendingMode.COLOR_BURN,
        "darken": BlendingMode.DARKEN, "lighten": BlendingMode.LIGHTEN, "difference": BlendingMode.DIFFERENCE,
        "exclusion": BlendingMode.EXCLUSION, "hue": BlendingMode.HUE, "saturation": BlendingMode.SATURATION,
        "color": BlendingMode.COLOR, "luminosity": BlendingMode.LUMINOSITY
    };

    var RE_AI_SUFFIX = /\/[^\/]*\.ai$/i;                       
    var RE_BLEND = /^(.*?)\s*\[([a-z\-]+)\]$/;                  
    var RE_MATTE = /^M(\d+) MATTE · /;                    
    var RE_CONTENT = /^(M(\d+) .*? · content) → Alpha Matte: M\d+ MATTE$/; 
    var RE_FRAME = /^FRAME (\d+)x(\d+)(?: @(\d+),(\d+))?/;
    var RE_GUIDES = /^(\u03BA\u03AC\u03B4\u03C1\u03BF|frame) \u00B7 guides/; 

    function selectedComps() {
        var out = [], sel = app.project.selection, i;
        for (i = 0; i < sel.length; i++) if (sel[i] instanceof CompItem) out.push(sel[i]);
        if (!out.length && app.project.activeItem instanceof CompItem) out.push(app.project.activeItem);
        return out;
    }

    function cleanNamesAndBlends(comp, rep) {
        for (var i = 1; i <= comp.numLayers; i++) {
            var L = comp.layer(i);
            var n = L.name, changed = false;
            if (RE_AI_SUFFIX.test(n)) { n = n.replace(RE_AI_SUFFIX, ""); changed = true; }
            var m = RE_BLEND.exec(n);
            if (m) {
                var mode = MODES[m[2]];
                if (mode !== undefined) {
                    try { L.blendingMode = mode; rep.blends++; n = m[1]; changed = true; }
                    catch (e) { rep.notes.push("'" + n + "': blend mode not applied (" + e.message + ")"); }
                } else {
                    rep.notes.push("'" + n + "': unknown tag [" + m[2] + "]");
                }
            }
            if (changed && n !== "") L.name = n;
        }
    }

    // ---- 3: mattes
    function linkMattes(comp, rep) {
        var mattes = {}, contents = [], i, L, m;
        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            if (RE_MATTE.test(L.name)) mattes[RE_MATTE.exec(L.name)[1]] = L;
            else if ((m = RE_CONTENT.exec(L.name))) contents.push({ layer: L, id: m[2], shortName: m[1] });
        }
        for (i = 0; i < contents.length; i++) {
            var c = contents[i], mt = mattes[c.id];
            if (!mt) { rep.notes.push("'" + c.layer.name + "': matte layer not found: M" + c.id + " MATTE"); continue; }
            try {
                if (typeof c.layer.setTrackMatte === "function") {

                    c.layer.setTrackMatte(mt, TrackMatteType.ALPHA);
                } else {

                    if (mt.index !== c.layer.index - 1) mt.moveBefore(c.layer);
                    c.layer.trackMatteType = TrackMatteType.ALPHA;
                }
                mt.enabled = false;
                c.layer.name = c.shortName;
                rep.mattes++;
            } catch (e) {
                rep.notes.push("'" + c.layer.name + "': matte not applied (" + e.message + ")");
            }
        }
    }

    function shiftProp(p, dx, dy) {

        var k;
        if (p.numKeys > 0) {
            for (k = 1; k <= p.numKeys; k++) {
                var v = p.keyValue(k);
                p.setValueAtKey(k, shifted(v, dx, dy));
            }
        } else {
            p.setValue(shifted(p.value, dx, dy));
        }
    }

    function shifted(v, dx, dy) {
        if (typeof v === "number") return v + dx; 
        var out = [v[0] + dx, v[1] + dy];
        if (v.length > 2) out.push(v[2]);
        return out;
    }

    function shiftLayer(L, dx, dy) {
        if (L.parent) return; 
        var tr = L.property("ADBE Transform Group");
        var pos = tr.property("ADBE Position");
        if (pos.dimensionsSeparated) {
            shiftProp(tr.property("ADBE Position_0"), dx, 0);
            shiftProp(tr.property("ADBE Position_1"), dy, 0);
        } else {
            shiftProp(pos, dx, dy);
        }

        var poi = tr.property("ADBE Anchor Point");
        if ((L instanceof CameraLayer || L instanceof LightLayer) && poi) shiftProp(poi, dx, dy);
    }

    function restoreFrame(comp, rep) {
        var frame = null, m = null, i;
        for (i = 1; i <= comp.numLayers; i++) {
            m = RE_FRAME.exec(comp.layer(i).name);
            if (m) { frame = comp.layer(i); break; }
        }
        for (i = comp.numLayers; i >= 1; i--) if (RE_GUIDES.test(comp.layer(i).name)) comp.layer(i).remove();
        if (!frame) return;
        var W = parseInt(m[1], 10), H = parseInt(m[2], 10);
        var hasXY = m[3] !== undefined && m[3] !== "";
        var X = hasXY ? parseInt(m[3], 10) : 0, Y = hasXY ? parseInt(m[4], 10) : 0;
        frame.remove();
        if (W === comp.width && H === comp.height) return;
        if (W > comp.width || H > comp.height) {
            rep.notes.push("FRAME " + W + "x" + H + " is larger than the comp: size not changed");
            return;
        }

        var dx = hasXY ? -X : -(comp.width - W) / 2, dy = hasXY ? -Y : -(comp.height - H) / 2;
        if (hasXY && (X + W > comp.width || Y + H > comp.height)) {
            rep.notes.push("FRAME @" + X + "," + Y + " falls outside the comp: size not changed");
            return;
        }
        var oldW = comp.width, oldH = comp.height;
        for (i = 1; i <= comp.numLayers; i++) {
            var L = comp.layer(i);
            try {
                var wasLocked = L.locked;
                L.locked = false;
                shiftLayer(L, dx, dy);
                L.locked = wasLocked;
            } catch (e) {
                rep.notes.push("'" + L.name + "': not moved (" + e.message + ")");
            }
        }
        comp.width = W;
        comp.height = H;
        rep.frame = oldW + "x" + oldH + " → " + W + "x" + H;
    }

    function organize(comp, rep) {
        var parent = comp.parentFolder, folder = null, i;
        for (i = 1; i <= parent.numItems; i++) {
            var it = parent.item(i);
            if (it instanceof FolderItem && it.name === comp.name) { folder = it; break; }
        }
        var oldFolders = {}, moved = 0;
        for (i = 1; i <= comp.numLayers; i++) {
            var src = comp.layer(i).source;
            if (!(src instanceof FootageItem)) continue;
            var f = null;
            try { f = src.mainSource.file; } catch (e) { f = null; }
            if (!f || !/\.ai$/i.test(f.name)) continue;
            if (!folder) { folder = app.project.items.addFolder(comp.name); folder.parentFolder = parent; }
            if (src.parentFolder === folder) continue;
            oldFolders[src.parentFolder.id] = src.parentFolder;
            src.parentFolder = folder;
            moved++;
        }

        for (var k in oldFolders) {
            if (!oldFolders.hasOwnProperty(k)) continue;
            var of = oldFolders[k];
            if (of !== app.project.rootFolder && of.numItems === 0) { try { of.remove(); } catch (e) {} }
        }
        rep.organized = moved;
    }

    function shiftPos(L, off) {
        var tr = L.property("ADBE Transform Group"), pos = tr.property("ADBE Position");
        function add(v, d) {
            if (typeof v === "number") return v + d;
            var o = [v[0] + d[0], v[1] + d[1]];
            if (v.length > 2) o.push(v[2]);
            return o;
        }
        function addTo(p, d) {
            if (p.numKeys > 0) { for (var k = 1; k <= p.numKeys; k++) p.setValueAtKey(k, add(p.keyValue(k), d)); }
            else p.setValue(add(p.value, d));
        }
        if (pos.dimensionsSeparated) { addTo(tr.property("ADBE Position_0"), off[0]); addTo(tr.property("ADBE Position_1"), off[1]); }
        else addTo(pos, off);
    }

    function hasExpr(p) { return p && p.canSetExpression && p.expressionEnabled && p.expression !== ""; }

    function setAnchorKeep(L, na) {
        var tr = L.property("ADBE Transform Group");
        var ap = tr.property("ADBE Anchor Point"), sc = tr.property("ADBE Scale"), rot = tr.property("ADBE Rotate Z");
        var pos = tr.property("ADBE Position");
        if (ap.numKeys > 0 || hasExpr(ap)) return "anchor has keyframes or an expression";
        if (sc.numKeys > 0 || (rot && rot.numKeys > 0) || hasExpr(sc) || hasExpr(rot)) return "scale/rotation has keyframes or an expression";
        if (pos.dimensionsSeparated ? (hasExpr(tr.property("ADBE Position_0")) || hasExpr(tr.property("ADBE Position_1"))) : hasExpr(pos)) return "position has an expression";
        if (L.threeDLayer) {
            var xr = tr.property("ADBE Rotate X"), yr = tr.property("ADBE Rotate Y"), orr = tr.property("ADBE Orientation");
            if ((xr && (xr.value !== 0 || xr.numKeys)) || (yr && (yr.value !== 0 || yr.numKeys)) ||
                (orr && (orr.value[0] || orr.value[1] || orr.value[2] || orr.numKeys))) return "3D layer with X/Y rotation or orientation";
        }
        var oa = ap.value, d = [na[0] - oa[0], na[1] - oa[1]];
        if (Math.abs(d[0]) < 0.001 && Math.abs(d[1]) < 0.001) return null;
        var s = sc.value, r = (rot ? rot.value : 0) * Math.PI / 180;
        var dx = d[0] * s[0] / 100, dy = d[1] * s[1] / 100;
        var off = [dx * Math.cos(r) - dy * Math.sin(r), dx * Math.sin(r) + dy * Math.cos(r)];
        var nv = [na[0], na[1]];
        if (oa.length > 2) nv.push(oa[2]);
        ap.setValue(nv);
        shiftPos(L, off);
        return null;
    }

    function centerAnchors(comp, rep) {
        for (var i = 1; i <= comp.numLayers; i++) {
            var L = comp.layer(i);
            if (!(L instanceof AVLayer) || L.nullLayer || L.guideLayer) continue;
            var r;
            try { r = L.sourceRectAtTime(comp.time, false); } catch (e) { continue; }
            if (!r || r.width <= 0 || r.height <= 0) continue;
            var wasLocked = L.locked;
            L.locked = false;
            try {
                var why = setAnchorKeep(L, [r.left + r.width / 2, r.top + r.height / 2]);
                if (why) rep.notes.push("'" + L.name + "': anchor not changed (" + why + ")");
                else rep.anchors++;
            } catch (e) {
                rep.notes.push("'" + L.name + "': anchor (" + e.message + ")");
            }
            L.locked = wasLocked;
        }
    }

    function showDialog(n) {
        var w = new Window("dialog", SCRIPT_NAME);
        w.orientation = "column";
        w.alignChildren = "left";
        w.add("statictext", undefined, n + " comp(s)");
        var cbB = w.add("checkbox", undefined, "Clean names + blend modes from tags like [screen]");
        var cbM = w.add("checkbox", undefined, "Track mattes from the M1, M2… pairs");
        var cbF = w.add("checkbox", undefined, "Crop the comp back to its FRAME");
        var cbO = w.add("checkbox", undefined, "Organise project: footage into one folder per comp");
        var cbA = w.add("checkbox", undefined, "Anchor point to the centre of each layer (nothing moves)");
        cbB.value = cbM.value = cbF.value = cbO.value = cbA.value = true;
        var g = w.add("group");
        g.alignment = "right";
        g.add("button", undefined, "Cancel", { name: "cancel" });
        g.add("button", undefined, "OK", { name: "ok" });
        if (w.show() !== 1) return null;
        return { blends: cbB.value, mattes: cbM.value, frame: cbF.value, organize: cbO.value, anchors: cbA.value };
    }

    function run(compsIn, optsIn) {
        if (!app.project) { alert("No project is open.", SCRIPT_NAME); return null; }
        var comps = compsIn || selectedComps();
        if (!comps.length) {
            var msg0 = "No comp found.\n\nSelect the comp (or comps) in the Project panel, or open one in the viewer, and run the script again.";
            if (!$.global.AE_SETUP_NO_UI) alert(msg0, SCRIPT_NAME);
            return { none: true, message: msg0 };
        }
        var opts = optsIn || ($.global.AE_SETUP_NO_UI ? { blends: true, mattes: true, frame: true, organize: true, anchors: true } : showDialog(comps.length));
        if (!opts) return { none: true, message: "" };
        var report = [], tot = { blends: 0, mattes: 0, frames: 0, anchors: 0, organized: 0 };
        app.beginUndoGroup(SCRIPT_NAME);
        try {
            for (var c = 0; c < comps.length; c++) {
                var comp = comps[c];
                var rep = { blends: 0, mattes: 0, frame: "", anchors: 0, organized: 0, notes: [] };
                if (opts.blends) cleanNamesAndBlends(comp, rep);
                if (opts.mattes) linkMattes(comp, rep);
                if (opts.frame) restoreFrame(comp, rep);
                if (opts.anchors) centerAnchors(comp, rep);
                if (opts.organize) organize(comp, rep);
                tot.blends += rep.blends; tot.mattes += rep.mattes; if (rep.frame) tot.frames++;
                tot.anchors += rep.anchors; tot.organized += rep.organized;
                var parts = [];
                if (rep.blends) parts.push(rep.blends + " blend modes");
                if (rep.mattes) parts.push(rep.mattes + " mattes");
                if (rep.frame) parts.push("comp " + rep.frame);
                if (rep.anchors) parts.push(rep.anchors + " anchors centred");
                if (rep.organized) parts.push(rep.organized + " footage moved to its folder");
                report.push(comp.name + ": " + (parts.length ? parts.join(", ") : "nothing to do") +
                    (rep.notes.length ? "\n   - " + rep.notes.join("\n   - ") : ""));
            }
        } finally {
            app.endUndoGroup();
        }
        var msg = comps.length + " comp(s): " + tot.blends + " blend modes, " + tot.mattes + " mattes, " +
                  tot.frames + " frames, " + tot.anchors + " anchors.\n\n" + report.join("\n\n");
        return { blends: tot.blends, mattes: tot.mattes, frames: tot.frames, message: msg };
    }

    $.global.AE_SETUP = { run: run };
    if ($.global.AE_SETUP_NO_UI) return;

    var res = run();
    if (res && !res.none) alert(res.message, SCRIPT_NAME);
})();
