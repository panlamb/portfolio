//@target illustrator
/*
    AI → AE Prep  ·  Illustrator script by Panos Lambrakis (panlamb.github.io/portfolio)

    Turns an Illustrator storyboard into files that After Effects can animate.
    For every artboard it saves a clean .ai where every object sits on its own named layer,
    in the original stacking order, ready for File > Import > Composition – Retain Layer Sizes.

    Your original file is never changed: the script works on a copy.
    Guide: AI_to_AE_Prep_GUIDE.txt (next to this file).

    Free to use in personal and commercial projects. Please don't resell or re-upload it;
    link to panlamb.github.io/portfolio/tools/ instead.
*/
(function () {
    var SCRIPT_NAME = "AI → AE Prep";
    var VERSION = "2.3";

    // ------------------------------------------------------------------ helpers

    function trim(s) { return String(s).replace(/^\s+|\s+$/g, ""); }

    function sanitize(s, maxLen) {

        s = trim(String(s).replace(/[\r\n\t\u0003]+/g, " ").replace(/\s{2,}/g, " ").replace(/\[/g, "(").replace(/\]/g, ")"));
        if (maxLen && s.length > maxLen) s = trim(s.substr(0, maxLen));
        return s;
    }

    function fileSafe(s) {
        return sanitize(s, 50).replace(/[\/\\:\*\?"<>\|]+/g, "-");
    }

    function baseName(f) {
        var n = decodeURI(f.name);
        var i = n.lastIndexOf(".");
        return i > 0 ? n.substr(0, i) : n;
    }

    function ext(f) {
        var n = f.name;
        var i = n.lastIndexOf(".");
        return i > 0 ? n.substr(i) : ".ai";
    }

    function pad(n) { return (n < 10 ? "0" : "") + n; }

    var TAG = "__ai2ae__";
    var TAG_DEL = TAG + "del";
    var TAG_ORIG = TAG + "orig";
    var TAG_LEAF = TAG + "leaf_";
    var TAG_FX = TAG + "fx";        
    var TAG_FXSRC = TAG + "fxsrc";  

    var SPLIT_BLEND = false;

    function blendTag(m) {
        switch (m) {
            case BlendModes.MULTIPLY: return "multiply";
            case BlendModes.SCREEN: return "screen";
            case BlendModes.OVERLAY: return "overlay";
            case BlendModes.SOFTLIGHT: return "soft-light";
            case BlendModes.HARDLIGHT: return "hard-light";
            case BlendModes.COLORDODGE: return "color-dodge";
            case BlendModes.COLORBURN: return "color-burn";
            case BlendModes.DARKEN: return "darken";
            case BlendModes.LIGHTEN: return "lighten";
            case BlendModes.DIFFERENCE: return "difference";
            case BlendModes.EXCLUSION: return "exclusion";
            case BlendModes.HUE: return "hue";
            case BlendModes.SATURATIONBLEND: return "saturation";
            case BlendModes.COLORBLEND: return "color";
            case BlendModes.LUMINOSITY: return "luminosity";
            default: return "";
        }
    }

    function hasBlendedDescendant(g) {
        for (var i = 0; i < g.pageItems.length; i++) {
            var it = g.pageItems[i];
            if (it.blendingMode !== BlendModes.NORMAL) return true;
            if (it.typename === "GroupItem" && !it.clipped && hasBlendedDescendant(it)) return true;
        }
        return false;
    }

    function sweepTagged(doc, tag) {
        var n = 0;
        for (var i = doc.pageItems.length - 1; i >= 0; i--) {
            var it = doc.pageItems[i];
            if (safe(function () { return it.note; }, "") === tag) {
                if (safe(function () { it.remove(); return true; }, false)) n++;
            }
        }
        return n;
    }

    function removeEmptyGroups(doc) {
        for (var pass = 0; pass < 20; pass++) {
            var removed = 0;
            for (var i = doc.groupItems.length - 1; i >= 0; i--) {
                var g = doc.groupItems[i];
                if (g.pageItems.length === 0) { g.remove(); removed++; }
            }
            if (!removed) break;
        }
    }

    function collectAll(doc, markExists) {
        var leaves = [];
        for (var i = 0; i < doc.layers.length; i++) {
            collectLeaves(doc.layers[i], rootContext(doc.layers[i], markExists), leaves);
        }
        return leaves;
    }

    function intersects(b, r) {
        // bounds/rect: [left, top, right, bottom] — y grows upwards
        return b[0] < r[2] && b[2] > r[0] && b[1] > r[3] && b[3] < r[1];
    }

    function safe(fn, fallback) {
        try { return fn(); } catch (e) { return fallback; }
    }

    function clipPathOf(g) {
        for (var i = 0; i < g.pageItems.length; i++) {
            var p = g.pageItems[i];
            if (p.typename === "PathItem" && p.clipping) return p;
            if (p.typename === "CompoundPathItem" && safe(function () { return p.pathItems.length > 0 && p.pathItems[0].clipping; }, false)) return p;
        }
        return null;
    }

    function artBounds(it) {
        if (it.typename === "GroupItem" && it.clipped) {
            var cp = clipPathOf(it);
            if (cp) { var cb = safe(function () { return cp.geometricBounds; }, null); if (cb) return cb; }
        }
        return safe(function () { return it.visibleBounds; }, null);
    }

    var OFF_MIN = 0.02;      
    var OFF_MIN_FAR = 0.15;  
    function isOffArtboard(b, r) {
        var f = overlapFrac(b, r);
        if (f < OFF_MIN) return true;
        var cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
        var centerIn = cx >= r[0] && cx <= r[2] && cy <= r[1] && cy >= r[3];
        return !centerIn && f < OFF_MIN_FAR;
    }
    function overlapFrac(b, r) {
        var bw = Math.max(b[2] - b[0], 0.5), bh = Math.max(b[1] - b[3], 0.5); 
        var cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
        var l = cx - bw / 2, rt = cx + bw / 2, t = cy + bh / 2, bt = cy - bh / 2;
        var w = Math.min(rt, r[2]) - Math.max(l, r[0]);
        var h = Math.min(t, r[1]) - Math.max(bt, r[3]);
        if (w <= 0 || h <= 0) return 0;
        return (w * h) / (bw * bh);
    }

    function groupHasOwnEffect(g) {
        if (g.clipped || g.pageItems.length === 0) return false;
        var gb = safe(function () { return g.visibleBounds; }, null);
        if (!gb) return false;
        var u = null;
        for (var i = 0; i < g.pageItems.length; i++) {
            var b = safe(function () { return g.pageItems[i].visibleBounds; }, null);
            if (!b) return false;
            if (!u) u = [b[0], b[1], b[2], b[3]];
            else { u[0] = Math.min(u[0], b[0]); u[1] = Math.max(u[1], b[1]); u[2] = Math.max(u[2], b[2]); u[3] = Math.min(u[3], b[3]); }
        }
        return Math.max(u[0] - gb[0], gb[1] - u[1], gb[2] - u[2], u[3] - gb[3]) > 1;
    }

    var ORDER_WARN = false;
    function layerChildren(L) {
        var items = [], subs = [], i;
        for (i = 0; i < L.pageItems.length; i++) items.push({ obj: L.pageItems[i], isLayer: false, k: i });
        for (i = 0; i < L.layers.length; i++) subs.push({ obj: L.layers[i], isLayer: true, k: i });
        if (!items.length || !subs.length) return items.concat(subs);
        var all = items.concat(subs), seen = {}, ok = true;
        for (i = 0; i < all.length; i++) {
            var o = all[i].obj;
            all[i].z = safe(function () { return o.zOrderPosition; }, null);
            if (all[i].z === null || seen[all[i].z]) { ok = false; break; }
            seen[all[i].z] = true;
        }
        if (ok) {

            var dir = 0;
            if (items.length > 1) dir = items[0].z > items[items.length - 1].z ? 1 : -1;
            else if (subs.length > 1) dir = subs[0].z > subs[subs.length - 1].z ? 1 : -1;
            else dir = 1; 
            all.sort(function (a, b) { return dir * (b.z - a.z); });
            var li = -1, ls = -1;
            for (i = 0; i < all.length; i++) {
                if (all[i].isLayer) { if (all[i].k < ls) ok = false; ls = all[i].k; }
                else { if (all[i].k < li) ok = false; li = all[i].k; }
            }
            if (ok) return all;
        }
        ORDER_WARN = true;
        return items.concat(subs);
    }

    function isAxisRect(p) {
        if (!p || p.typename !== "PathItem" || !p.closed || p.pathPoints.length !== 4) return false;
        for (var i = 0; i < 4; i++) {
            var a = p.pathPoints[i], b = p.pathPoints[(i + 1) % 4];
            var A = a.anchor, B = b.anchor;
            if (Math.abs(a.leftDirection[0] - A[0]) + Math.abs(a.leftDirection[1] - A[1]) +
                Math.abs(a.rightDirection[0] - A[0]) + Math.abs(a.rightDirection[1] - A[1]) > 0.01) return false;
            if (Math.abs(A[0] - B[0]) > 0.01 && Math.abs(A[1] - B[1]) > 0.01) return false;
        }
        return true;
    }

    function inside(b, r) { return b[0] >= r[0] - 0.5 && b[2] <= r[2] + 0.5 && b[1] <= r[1] + 0.5 && b[3] >= r[3] - 0.5; }

    function liftTextsFromClipGroups(doc) {
        var n = 0;
        for (var gi = doc.groupItems.length - 1; gi >= 0; gi--) {
            var g = doc.groupItems[gi];
            if (!g.clipped || g.opacity < 99.9 || g.blendingMode !== BlendModes.NORMAL) continue;
            var cp = clipPathOf(g);
            if (!isAxisRect(cp)) continue;
            var cb = cp.geometricBounds, run = [];
            for (var k = 0; k < g.pageItems.length; k++) {
                var c = g.pageItems[k];
                if (c === cp || (c.typename === "PathItem" && c.clipping)) continue;
                if (c.typename !== "TextFrame") break;   
                var vb = safe(function () { return c.visibleBounds; }, null);
                if (!vb || !inside(vb, cb)) break;
                run.push(c);
            }
            for (var r = 0; r < run.length; r++) {      
                if (safe(function () { run[r].move(g, ElementPlacement.PLACEBEFORE); return true; }, false)) n++;
            }
        }
        return n;
    }

    var RE_MATTE_PAIR = /^M\d+ /;
    var RE_MATTE_CONTENT = /^M\d+ .* \u00B7 content \u2192 /;

    function isMatteContent(it) {
        return RE_MATTE_CONTENT.test(safe(function () { return it.name; }, ""));
    }

    function inClipGroup(it) {
        var p = safe(function () { return it.parent; }, null);
        while (p && p.typename === "GroupItem") {
            if (p.clipped) return true;
            p = safe(function () { return p.parent; }, null);
        }
        return false;
    }

    function paintMatte(m) {
        var white = new RGBColor(); white.red = 255; white.green = 255; white.blue = 255;
        var paths = [], k;
        if (m.typename === "CompoundPathItem") { for (k = 0; k < m.pathItems.length; k++) paths.push(m.pathItems[k]); }
        else paths.push(m);
        for (k = 0; k < paths.length; k++) {
            var q = paths[k];
            safe(function () { q.clipping = false; });
            q.filled = true; q.fillColor = white; q.stroked = false;
        }
        safe(function () { m.opacity = 100; m.blendingMode = BlendModes.NORMAL; });
    }

    function unclip(g, cp) {
        if (!safe(function () { g.clipped = false; return true; }, false)) return false;
        safe(function () { cp.remove(); });
        return true;
    }

    function handleClipGroups(doc, abRect, mode, stats) {
        if (mode === "keep") return;
        var list = [], i;
        for (i = 0; i < doc.groupItems.length; i++) if (doc.groupItems[i].clipped) list.push(doc.groupItems[i]);
        for (i = 0; i < list.length; i++) {
            var g = list[i];
            var cp = clipPathOf(g);
            if (!cp) continue;                       
            var cb = safe(function () { return cp.geometricBounds; }, null);
            if (!cb) continue;

            if (isAxisRect(cp) && inside(abRect, cb)) {
                if (unclip(g, cp)) stats.clipReleased = (stats.clipReleased || 0) + 1;
                continue;
            }
            if (mode !== "matte" || inClipGroup(g)) continue;
            var base = sanitize(safe(function () { return g.name; }, ""), 30);
            if (base === "") base = "mask " + (i + 1);
            var m = safe(function () { return cp.duplicate(g, ElementPlacement.PLACEBEFORE); }, null); 
            if (!m) continue;
            paintMatte(m);
            if (!unclip(g, cp)) { safe(function () { m.remove(); }); continue; }
            stats.clipMatte = (stats.clipMatte || 0) + 1;
            var mid = "M" + stats.clipMatte;
            m.name = mid + " MATTE \u00B7 " + base;
            g.name = mid + " " + base + " \u00B7 content \u2192 Alpha Matte: " + mid + " MATTE";
        }
    }

    function padArtboard(doc, pct, stats) {
        var ab = doc.artboards[0], r = ab.artboardRect;
        var W = r[2] - r[0], H = r[1] - r[3];
        if (!(pct > 0)) return;
        var u = null;
        for (var i = 0; i < doc.layers.length; i++) {
            var L = doc.layers[i];
            for (var j = 0; j < L.pageItems.length; j++) {
                var b = artBounds(L.pageItems[j]);
                if (!b) continue;
                if (!u) u = [b[0], b[1], b[2], b[3]];
                else { u[0] = Math.min(u[0], b[0]); u[1] = Math.max(u[1], b[1]); u[2] = Math.max(u[2], b[2]); u[3] = Math.min(u[3], b[3]); }
            }
        }
        if (!u) return;
        var mx = Math.ceil(Math.min(Math.max(r[0] - u[0], u[2] - r[2], 0), W * pct / 100));
        var my = Math.ceil(Math.min(Math.max(u[1] - r[1], r[3] - u[3], 0), H * pct / 100));
        if (mx < 1 && my < 1) return;

        var w0 = Math.round(W), h0 = Math.round(H);
        var FL = doc.layers.add(); 
        var fr = FL.pathItems.rectangle(r[1], r[0], W, H);
        var mag = new RGBColor(); mag.red = 255; mag.green = 0; mag.blue = 255;
        fr.filled = false; fr.stroked = true; fr.strokeWidth = 2; fr.strokeColor = mag;
        fr.name = "frame " + w0 + "x" + h0;
        FL.name = "FRAME " + w0 + "x" + h0 + " · the frame: Composition Settings " + w0 + "x" + h0 + ", Anchor: centre";
        ab.artboardRect = [r[0] - mx, r[1] + my, r[2] + mx, r[3] - my];
        FL.visible = false;
        stats.padX = mx; stats.padY = my;
        stats.frameW = w0; stats.frameH = h0;
        stats.compW = Math.round(W + 2 * mx); stats.compH = Math.round(H + 2 * my);
    }

    function whereIs(tf) {
        var p = safe(function () { return tf.parent; }, null);
        if (!p) return "?";
        if (p.typename === "Layer") return "on the same layer as " + (p.pageItems.length - 1) + " other objects";
        if (p.typename === "GroupItem") return p.clipped ? "inside a clipping group" : "inside a group";
        return "inside " + p.typename;
    }

    function markOrigDeep(g) {
        for (var i = 0; i < g.pageItems.length; i++) {
            var c = g.pageItems[i];
            if (c.typename === "GroupItem" && !c.clipped) { c.note = TAG_ORIG; markOrigDeep(c); }
        }
    }

    function missingLinks(doc) {
        var out = [];
        for (var i = 0; i < doc.placedItems.length; i++) {
            var p = doc.placedItems[i];
            var f = safe(function () { return p.file; }, null);
            if (!f || !f.exists) out.push(p.name !== "" ? p.name : (f ? decodeURI(f.name) : "linked image " + (i + 1)));
        }
        return out;
    }

    // ------------------------------------------------------------------ dialog

    function showDialog(doc, src) {
        var w = new Window("dialog", SCRIPT_NAME + "  v" + VERSION);
        w.orientation = "column";
        w.alignChildren = "fill";

        w.add("statictext", undefined, decodeURI(src.name) + "  —  " + doc.artboards.length + " artboard(s)");

        var p1 = w.add("panel", undefined, "Clean-up");
        p1.alignChildren = "left";
        p1.margins = [12, 16, 12, 10];
        var cbRGB = p1.add("checkbox", undefined, "Convert to RGB");
        var cbHidden = p1.add("checkbox", undefined, "Delete hidden items, guides, stray points, empty layers/groups");
        var cbOff = p1.add("checkbox", undefined, "Delete everything outside the artboard");
        var cbSym = p1.add("checkbox", undefined, "Break link to symbols");
        var cbExpand = p1.add("checkbox", undefined, "Expand appearance / effects / brushes (not text)");
        var cbOutline = p1.add("checkbox", undefined, "Create outlines from text");
        cbRGB.value = cbHidden.value = cbOff.value = cbSym.value = cbExpand.value = true;
        cbOutline.value = false;

        var p2 = w.add("panel", undefined, "Layers");
        p2.alignChildren = "left";
        p2.margins = [12, 16, 12, 10];
        p2.add("statictext", undefined, "Every object on its own top-level layer (clipping groups stay whole).");
        var cbPrefix = p2.add("checkbox", undefined, "Prefix each layer name with its original layer/group");
        cbPrefix.value = true;
        var cbBlend = p2.add("checkbox", undefined, "Blend modes: own layer, mode in the name (e.g. [screen])");
        cbBlend.value = true;

        var pc = w.add("panel", undefined, "Clipping masks (for motion in AE)");
        pc.alignChildren = "left";
        pc.margins = [12, 16, 12, 10];
        var rbRelease = pc.add("radiobutton", undefined, "Artboard-sized masks: remove them (the comp already crops); keep the others whole");
        var rbMatte = pc.add("radiobutton", undefined, "As above + other masks as pairs \"M1 MATTE\" / \"M1 … content → Alpha Matte\" (Track Matte in AE)");
        var rbKeep = pc.add("radiobutton", undefined, "No change: all clipping groups stay whole");
        rbRelease.value = true;
        var gPad = pc.add("group");
        gPad.add("statictext", undefined, "Margin around the artboard for zoom out / pan, up to");
        var etPad = gPad.add("edittext", undefined, "15");
        etPad.characters = 4;
        gPad.add("statictext", undefined, "% per side (0 = off)");

        var p3 = w.add("panel", undefined, "Output");
        p3.alignChildren = "fill";
        p3.margins = [12, 16, 12, 10];
        var g = p3.add("group");
        g.alignChildren = "center";
        var defOut = new Folder(src.parent.fsName + "/" + baseName(src) + "_AE");
        var etOut = g.add("edittext", undefined, defOut.fsName);
        etOut.preferredSize.width = 380;
        var btBrowse = g.add("button", undefined, "Change…");
        btBrowse.onClick = function () {
            var f = Folder.selectDialog("Output folder", src.parent);
            if (f) etOut.text = f.fsName;
        };
        var cbOpen = p3.add("checkbox", undefined, "Open the new files in Illustrator when done");
        cbOpen.value = true;
        var cbJson = p3.add("checkbox", undefined, "Write .text.json (for AE_Finish)");
        cbJson.value = false;

        var btns = w.add("group");
        btns.alignment = "right";
        btns.add("button", undefined, "Cancel", { name: "cancel" });
        btns.add("button", undefined, "OK", { name: "ok" });

        if (w.show() !== 1) return null;
        return {
            rgb: cbRGB.value,
            cleanHidden: cbHidden.value,
            offArtboard: cbOff.value,
            breakSymbols: cbSym.value,
            expand: cbExpand.value,
            outlineText: cbOutline.value,
            prefix: cbPrefix.value,
            aeBlend: cbBlend.value,
            openResults: cbOpen.value,
            writeJson: cbJson.value,
            clipMode: rbMatte.value ? "matte" : (rbKeep.value ? "keep" : "release"),
            padPct: Math.max(0, Math.min(100, parseFloat(etPad.text) || 0)),
            outPath: etOut.text
        };
    }

    // ------------------------------------------------------------------ cleanup passes

    function removeHiddenLayers(container) {
        var n = 0;
        for (var i = container.layers.length - 1; i >= 0; i--) {
            var L = container.layers[i];
            if (!L.visible) {
                L.locked = false;
                L.visible = true;
                L.remove();
                n++;
            } else {
                n += removeHiddenLayers(L);
            }
        }
        return n;
    }

    function unlockLayers(container) {
        for (var i = 0; i < container.layers.length; i++) {
            var L = container.layers[i];
            L.locked = false;
            if (!L.visible) {
                L.visible = true;
                L.name = "__ai2ae_hidden__" + L.name; 
            }
            unlockLayers(L);
        }
    }

    function unlockItems(doc) {
        for (var i = 0; i < doc.pageItems.length; i++) {
            var it = doc.pageItems[i];
            if (it.locked) safe(function () { it.locked = false; });
        }
    }

    function removeJunkItems(doc, stats) {
        for (var i = doc.pageItems.length - 1; i >= 0; i--) {
            var it = safe(function () { return doc.pageItems[i]; }, null);
            if (!it) continue;
            var kill = false;
            var why = "";
            if (it.hidden) { kill = true; why = "hidden"; }
            else if (it.typename === "PathItem" && it.guides) { kill = true; why = "guides"; }
            else if (it.typename === "PathItem" && it.pathPoints.length < 2 && !it.clipping) { kill = true; why = "stray"; }
            else if (it.typename === "TextFrame" && trim(it.contents) === "") { kill = true; why = "emptyText"; }
            if (kill) {
                if (safe(function () { it.remove(); return true; }, false)) stats[why] = (stats[why] || 0) + 1;
            }
        }
    }

    function breakSymbols(doc, stats) {

        for (var pass = 0; pass < 10 && doc.symbolItems.length > 0; pass++) {
            for (var i = doc.symbolItems.length - 1; i >= 0; i--) {
                var s = doc.symbolItems[i];
                if (safe(function () { s.breakLink(); return true; }, false)) stats.symbols = (stats.symbols || 0) + 1;
            }
        }
    }

    // ------------------------------------------------------------------ leaf collection

    function collectLeaves(container, ctx, out) {
        var isLayer = container.typename === "Layer";
        var i, it, kids;

        if (isLayer) kids = layerChildren(container);
        else { kids = []; for (i = 0; i < container.pageItems.length; i++) kids.push({ obj: container.pageItems[i], isLayer: false }); }

        for (i = 0; i < kids.length; i++) {
            if (kids[i].isLayer) {
                var L = kids[i].obj;
                var pl = parseLayerName(L);
                collectLeaves(L, {
                    markExists: ctx.markExists,
                    layerName: pl.name,
                    groupName: "",
                    opacity: ctx.opacity * (L.opacity / 100),
                    blend: (L.blendingMode !== BlendModes.NORMAL) ? L.blendingMode : ctx.blend,
                    hidden: ctx.hidden || pl.hidden
                }, out);
                continue;
            }
            it = kids[i].obj;

            if (it.typename === "GroupItem" && !it.clipped &&
                !isMatteContent(it) &&
                (!ctx.markExists || it.note === TAG_ORIG || (SPLIT_BLEND && hasBlendedDescendant(it)))) {
                var gname = sanitize(it.name, 40);
                collectLeaves(it, {
                    markExists: ctx.markExists,
                    layerName: ctx.layerName,
                    groupName: gname !== "" ? gname : ctx.groupName,
                    opacity: ctx.opacity * (it.opacity / 100),
                    blend: (it.blendingMode !== BlendModes.NORMAL) ? it.blendingMode : ctx.blend,
                    hidden: ctx.hidden || it.hidden
                }, out);
            } else {
                out.push({
                    item: it,
                    layerName: ctx.layerName,
                    groupName: ctx.groupName,
                    opacity: ctx.opacity,
                    blend: ctx.blend,
                    hidden: ctx.hidden
                });
            }
        }
        return out;
    }

    function parseLayerName(L) {
        var n = L.name;
        return {
            hidden: n.indexOf("__ai2ae_hidden__") >= 0,
            name: sanitize(n.replace(/__ai2ae_[a-z]+__/g, ""), 40)
        };
    }

    function rootContext(L, markExists) {
        var pl = parseLayerName(L);
        return {
            markExists: !!markExists,
            layerName: pl.name,
            groupName: "",
            opacity: L.opacity / 100,
            blend: safe(function () { return L.blendingMode; }, BlendModes.NORMAL),
            hidden: pl.hidden
        };
    }

    // ------------------------------------------------------------------ naming

    function describe(it) {
        var raw = safe(function () { return it.name; }, "");
        var n = sanitize(raw, RE_MATTE_PAIR.test(raw) ? 100 : 40);
        if (n !== "") return n;
        switch (it.typename) {
            case "TextFrame":
                var c = sanitize(safe(function () { return it.contents; }, ""), 24);
                return c !== "" ? "txt " + c : "text";
            case "PathItem": return "shape";
            case "CompoundPathItem": return "compound";
            case "GroupItem": return it.clipped ? "clipgroup" : "group";
            case "PlacedItem":
                var f = safe(function () { return baseName(it.file); }, "");
                return f !== "" ? "img " + sanitize(f, 30) : "image";
            case "RasterItem": return "raster";
            case "SymbolItem": return "symbol " + sanitize(safe(function () { return it.symbol.name; }, ""), 30);
            case "MeshItem": return "mesh";
            case "PluginItem": return "plugin";
            default: return it.typename.replace(/Item$/, "").toLowerCase();
        }
    }

    function makeNamer() {
        var used = {};
        return function (leaf, usePrefix) {
            var parts = [];
            var own = describe(leaf.item);
            if (usePrefix && !RE_MATTE_PAIR.test(own)) {
                if (leaf.layerName) parts.push(leaf.layerName);
                if (leaf.groupName) parts.push(leaf.groupName);
            }
            parts.push(own);
            var base = parts.join(" / ");
            var key = base.toLowerCase();
            if (!used[key]) { used[key] = 1; return base; }
            used[key]++;
            return base + " " + pad(used[key]);
        };
    }

    // ------------------------------------------------------------------ per artboard

    function prepArtboard(doc, abIndex, opts, warnings) {
        var stats = {};
        doc.selection = null;

        if (opts.rgb && doc.documentColorSpace !== DocumentColorSpace.RGB) {
            app.executeMenuCommand("doc-color-rgb");
        }

        var abRect = doc.artboards[abIndex].artboardRect;
        SPLIT_BLEND = !!opts.aeBlend;

        safe(function () {
            var rs = doc.rasterEffectSettings;
            rs.transparency = true;
            if (rs.resolution < 300) rs.resolution = 300;
            doc.rasterEffectSettings = rs;
        });

        if (opts.cleanHidden) stats.hiddenLayers = removeHiddenLayers(doc);
        unlockLayers(doc);
        unlockItems(doc);

        if (opts.cleanHidden) removeJunkItems(doc, stats);

        // 3. symbols
        if (opts.breakSymbols) breakSymbols(doc, stats);

        for (var j = doc.artboards.length - 1; j >= 0; j--) {
            if (j !== abIndex) doc.artboards.remove(j);
        }

        var i, leaves;

        for (i = 0; i < doc.layers.length; i++) doc.layers[i].name = "__ai2ae_old__" + doc.layers[i].name;

        if (opts.offArtboard) {
            leaves = collectAll(doc, false);
            for (i = 0; i < leaves.length; i++) {
                var b = artBounds(leaves[i].item);
                if (b && isOffArtboard(b, abRect)) leaves[i].item.note = TAG_DEL;
            }
            stats.offArtboard = sweepTagged(doc, TAG_DEL);
        }
        removeEmptyGroups(doc);

        stats.txtLifted = liftTextsFromClipGroups(doc);

        handleClipGroups(doc, abRect, opts.clipMode, stats);

        for (i = 0; i < doc.groupItems.length; i++) doc.groupItems[i].note = isMatteContent(doc.groupItems[i]) ? "" : TAG_ORIG;

        if (opts.expand) {
            for (i = 0; i < doc.groupItems.length; i++) {
                var gi = doc.groupItems[i];
                if (gi.note === TAG_ORIG && groupHasOwnEffect(gi)) { gi.note = TAG_FX; stats.fxGroups = (stats.fxGroups || 0) + 1; }
            }
        }

        stats.txtStart = doc.textFrames.length; 

        if (opts.outlineText) {
            var skip = 0;
            while (doc.textFrames.length > skip) {
                var tf = doc.textFrames[skip];
                var tname = tf.name !== "" ? tf.name : "txt " + sanitize(tf.contents, 24);
                var og = safe(function () { return tf.createOutline(); }, null);
                if (og) { og.name = tname; stats.outlined = (stats.outlined || 0) + 1; }
                else skip++;
            }
        }

        if (opts.expand) {
            var TAG_EXP = TAG + "exp_";
            leaves = collectAll(doc, true);
            for (i = 0; i < leaves.length; i++) {
                var it = leaves[i].item;
                var t = it.typename;
                if (t === "TextFrame" || t === "PlacedItem" || t === "RasterItem" || it.hidden) continue;
                it.note = TAG_EXP + (it.note === TAG_FX ? "fx|" : "-|") + it.name;
            }
            for (i = doc.pageItems.length - 1; i >= 0; i--) {
                var pi = doc.pageItems[i];
                var nt = safe(function () { return pi.note; }, "");
                if (nt.indexOf(TAG_EXP) !== 0) continue;
                var rest = nt.substr(TAG_EXP.length);
                var isFx = rest.indexOf("fx|") === 0;
                var keepName = rest.substr(3);
                pi.note = isFx ? TAG_FXSRC : ""; 
                doc.selection = null;
                if (!safe(function () { pi.selected = true; return true; }, false)) continue;
                app.executeMenuCommand("expandStyle");
                var sel = doc.selection;
                if (sel && sel.length === 1) {
                    if (sel[0].name === "" && keepName !== "") sel[0].name = keepName;
                    if (sel[0].typename === "GroupItem") {
                        if (isFx) {

                            sel[0].note = TAG_ORIG;
                            markOrigDeep(sel[0]);
                        } else {
                            sel[0].note = "";
                        }
                    }
                }
            }
            doc.selection = null;
        }

        if (typeof $.global.AI2AE_TEST_AFTER_EXPAND === "function") $.global.AI2AE_TEST_AFTER_EXPAND(doc); 

        stats.txtAfterExpand = doc.textFrames.length;

        ORDER_WARN = false;
        leaves = collectAll(doc, true);
        if (ORDER_WARN) {
            warnings.push("artboard " + (abIndex + 1) + ": a layer mixes objects and sublayers — check the stacking order.");
        }

        var namer = makeNamer();
        var lnames = [];
        for (i = 0; i < leaves.length; i++) {
            lnames[i] = namer(leaves[i], opts.prefix);
            leaves[i].item.note = TAG_LEAF + i;
        }
        var lookup = null;
        function findLeaf(k) {
            var ref = leaves[k].item;
            if (safe(function () { return ref.note; }, "") === TAG_LEAF + k) return ref;
            if (!lookup) {
                lookup = {};
                for (var q = 0; q < doc.pageItems.length; q++) {
                    var n = safe(function () { return doc.pageItems[q].note; }, "");
                    if (n.indexOf(TAG_LEAF) === 0) lookup[n] = doc.pageItems[q];
                }
            }
            return lookup[TAG_LEAF + k] || null;
        }

        var blendLost = 0, missing = 0, lostNames = [];
        for (i = leaves.length - 1; i >= 0; i--) {
            var leaf = leaves[i];
            var item = findLeaf(i);
            if (!item) { missing++; continue; }
            var NL = doc.layers.add();
            NL.name = lnames[i];
            item.move(NL, ElementPlacement.PLACEATBEGINNING);
            item.note = "";
            lookup = null; 
            if (leaf.opacity < 0.999) item.opacity = item.opacity * leaf.opacity;
            var effBlend = item.blendingMode;
            if (leaf.blend !== BlendModes.NORMAL) {
                if (effBlend === BlendModes.NORMAL) effBlend = leaf.blend;
                else if (effBlend !== leaf.blend) { blendLost++; lostNames.push(lnames[i]); }
            }

            item.blendingMode = effBlend;
            var tag = blendTag(effBlend);
            if (tag) {
                stats.blended = (stats.blended || 0) + 1;
                if (opts.aeBlend) NL.name = lnames[i] + " [" + tag + "]";
            }
            if (leaf.hidden) NL.visible = false;
        }
        if (blendLost) warnings.push("artboard " + (abIndex + 1) + ": " + blendLost + " objects had a blend mode on both their group and themselves — their own was kept (check them in AE): " + lostNames.join(", "));

        for (i = 0; i < doc.pageItems.length; i++) {
            var pn = doc.pageItems[i];
            if (safe(function () { return pn.note; }, "").indexOf(TAG) === 0) safe(function () { pn.note = ""; });
        }

        for (i = doc.layers.length - 1; i >= 0; i--) {
            var OL = doc.layers[i];
            if (OL.name.indexOf("__ai2ae_old__") !== 0) continue;
            var leftovers = collectLeaves(OL, rootContext(OL, false), []);
            if (leftovers.length === 0) {
                OL.remove();
            } else {
                OL.name = "⚠ leftovers — " + parseLayerName(OL).name;
                warnings.push("artboard " + (abIndex + 1) + ": some objects could not be moved (layer '⚠ leftovers').");
            }
        }
        if (missing) warnings.push("artboard " + (abIndex + 1) + ": " + missing + " objects could not be found to move.");

        stats.layers = leaves.length - missing;

        stats.txtAlone = 0;
        stats.txtWhere = [];
        for (i = 0; i < doc.textFrames.length; i++) {
            var tfi = doc.textFrames[i];
            var par = safe(function () { return tfi.parent; }, null);
            if (par && par.typename === "Layer" && par.pageItems.length === 1) { stats.txtAlone++; continue; }
            if (stats.txtWhere.length < 6) stats.txtWhere.push('"' + sanitize(safe(function () { return tfi.contents; }, ""), 18) + '" ' + whereIs(tfi));
        }

        padArtboard(doc, opts.padPct, stats);

        return stats;
    }

    function jsonStr(v) {
        if (v === null || v === undefined) return "null";
        var t = typeof v;
        if (t === "number") return isFinite(v) ? String(Math.round(v * 1000) / 1000) : "null";
        if (t === "boolean") return v ? "true" : "false";
        if (t === "string") {
            return '"' + v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t") + '"';
        }
        var i, out = [];
        if (v instanceof Array) {
            for (i = 0; i < v.length; i++) out.push(jsonStr(v[i]));
            return "[" + out.join(",") + "]";
        }
        for (var k in v) if (v.hasOwnProperty(k)) out.push(jsonStr(k) + ":" + jsonStr(v[k]));
        return "{" + out.join(",") + "}";
    }

    function collectTexts(doc) {
        var out = [];
        var ab = doc.artboards[0].artboardRect; 
        for (var li = 0; li < doc.layers.length; li++) {
            var L = doc.layers[li];
            if (L.pageItems.length !== 1) continue;
            var tf = L.pageItems[0];
            if (tf.typename !== "TextFrame") continue;
            var rec = { layer: L.name.replace(/ \[[a-z\-]+\]$/, ""), convert: true, reason: "" };
            function no(why) { if (rec.convert) { rec.convert = false; rec.reason = why; } }
            var kind = safe(function () { return tf.kind; }, null);
            var ks = String(kind);
            rec.kind = ks.indexOf("POINT") >= 0 ? "point" : (ks.indexOf("AREA") >= 0 ? "area" : "path");
            if (rec.kind === "path") no("text on path");
            if (rec.kind === "area") no("area type (paragraph): stays an image");
            rec.contents = safe(function () { return tf.contents; }, "");
            rec.opacity = tf.opacity;

            var chars = safe(function () { return tf.textRange.characters; }, null);
            var first = null, mixed = false;
            if (chars) {
                var n = Math.min(chars.length, 600);
                for (var ci = 0; ci < n; ci++) {
                    if (/^\s$/.test(chars[ci].contents)) continue;
                    var cur = safe(function () {
                        var ca = chars[ci].characterAttributes;
                        var fc = ca.fillColor;
                        var o = { font: ca.textFont.name, size: ca.size, tracking: ca.tracking, autoLeading: ca.autoLeading, leading: ca.leading,
                                  stroked: !!ca.stroked, ftype: fc.typename,
                                  hScale: safe(function () { return ca.horizontalScale; }, 100), vScale: safe(function () { return ca.verticalScale; }, 100),
                                  baseline: safe(function () { return ca.baselineShift; }, 0),
                                  caps: String(safe(function () { return ca.capitalization; }, "")),
                                  basePos: String(safe(function () { return ca.baselinePosition; }, "")),
                                  underline: !!safe(function () { return ca.underline; }, false), strike: !!safe(function () { return ca.strikeThrough; }, false) };
                        if (fc.typename === "RGBColor") o.fill = [Math.round(fc.red), Math.round(fc.green), Math.round(fc.blue)];
                        o.sig = [o.font, Math.round(o.size * 100), Math.round(o.tracking), o.autoLeading ? "a" : Math.round(o.leading * 100), o.ftype, o.fill ? o.fill.join(",") : "",
                                   Math.round(o.hScale), Math.round(o.vScale), Math.round(o.baseline * 100), o.caps, o.basePos, o.underline, o.strike].join("|");
                        return o;
                    }, null);
                    if (!cur) { no("could not read its attributes"); break; }
                    if (first === null) first = cur;
                    else if (first.sig !== cur.sig) { mixed = true; break; }
                }
            }
            if (mixed) no("mixed styles");
            if (first === null) { no("empty text"); }
            else {
                rec.font = first.font; rec.size = first.size; rec.tracking = first.tracking;
                rec.autoLeading = first.autoLeading; rec.leading = first.leading;
                if (first.fill) rec.fill = first.fill; else no("fill is not plain RGB");
                if (first.stroked) no("has a stroke");
                rec.hScale = first.hScale; rec.vScale = first.vScale; rec.baseline = first.baseline;
                rec.allCaps = first.caps.indexOf("ALLCAPS") >= 0;
                if (first.caps.indexOf("SMALLCAPS") >= 0) no("small caps");
                if (first.basePos.indexOf("SUPER") >= 0 || first.basePos.indexOf("SUB") >= 0) no("superscript/subscript");
                if (first.underline) no("underline");
                if (first.strike) no("strikethrough");
            }
            var just = safe(function () { return tf.textRange.paragraphAttributes.justification; }, Justification.LEFT);
            var pa = safe(function () { return tf.textRange.paragraphs[0].paragraphAttributes; }, null);
            if (pa) {
                rec.spaceBefore = safe(function () { return pa.spaceBefore; }, 0);
                rec.spaceAfter = safe(function () { return pa.spaceAfter; }, 0);
                rec.firstLineIndent = safe(function () { return pa.firstLineIndent; }, 0);
            }
            var js = String(just);
            var isFull = js.indexOf("FULL") >= 0;
            rec.justify = (!isFull && js.indexOf("CENTER") >= 0) ? "center" : ((!isFull && js.indexOf("RIGHT") >= 0) ? "right" : "left");
            if (isFull) no("full justify");

            if (rec.kind === "point") {
                var an = safe(function () { return tf.anchor; }, null);
                if (an) { rec.x = an[0] - ab[0]; rec.y = ab[1] - an[1]; } else no("anchor not found");
            } else if (rec.kind === "area") {
                var gb = safe(function () { return tf.textPath.geometricBounds; }, null); // [l, t, r, b]
                if (gb) { rec.x = gb[0] - ab[0]; rec.y = ab[1] - gb[1]; rec.w = gb[2] - gb[0]; rec.h = gb[1] - gb[3]; } else no("frame not found");
            }

            var vb = safe(function () { return tf.visibleBounds; }, null), gbt = safe(function () { return tf.geometricBounds; }, null);
            if (vb && gbt) {
                var grow = Math.max(gbt[0] - vb[0], vb[1] - gbt[1], vb[2] - gbt[2], gbt[3] - vb[3]);
                if (grow > 1.5) no("effect on the text (e.g. a shadow)");

                rec.gx = gbt[0] - ab[0]; rec.gy = ab[1] - gbt[1]; rec.gw = gbt[2] - gbt[0]; rec.gh = gbt[1] - gbt[3];
            }

            var mx = safe(function () { return tf.matrix; }, null);
            if (mx && (Math.abs(mx.mValueA - 1) > 0.001 || Math.abs(mx.mValueB) > 0.001 ||
                       Math.abs(mx.mValueC) > 0.001 || Math.abs(mx.mValueD - 1) > 0.001)) {
                no("rotated/skewed/scaled frame");
            }
            out.push(rec);
        }

        var cnt = {}, j;
        for (j = 0; j < out.length; j++) { var key = trim(out[j].contents).toLowerCase(); cnt[key] = (cnt[key] || 0) + 1; }
        for (j = 0; j < out.length; j++) {
            if (cnt[trim(out[j].contents).toLowerCase()] > 1 && out[j].convert) {
                out[j].convert = false;
                out[j].reason = "copies of the same text (extrude/shadow): stays an image so they stay together";
            }
        }
        return out;
    }

    function writeSidecar(aiFile, texts) {
        var jf = new File(aiFile.fsName.replace(/\.ai$/i, "") + ".text.json");
        jf.encoding = "UTF-8";
        if (!jf.open("w")) return null;
        jf.write(jsonStr({ version: 1, texts: texts }));
        jf.close();
        return jf;
    }

    // ------------------------------------------------------------------ main

    function processFile(src, opts) {
        var outFolder = new Folder(opts.outPath);
        if (!outFolder.exists && !outFolder.create()) throw new Error("Could not create the folder: " + opts.outPath);

        var stamp = new Date().getTime();
        var tmp = new File(src.parent.fsName + "/.ai2ae_tmp_" + stamp + ext(src));
        if (!src.copy(tmp.fsName)) {
            tmp = new File(Folder.temp.fsName + "/ai2ae_tmp_" + stamp + ext(src));
            if (!src.copy(tmp.fsName)) throw new Error("Could not copy the file.");
        }

        var prevUIL = app.userInteractionLevel;
        app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
        var prevCS = safe(function () { return app.coordinateSystem; }, null);
        safe(function () { app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM; });

        var lines = [];
        var warnings = [];
        var abNames = [];
        var outFiles = [];
        try {
            var d0 = app.open(tmp);
            for (var a = 0; a < d0.artboards.length; a++) abNames.push(d0.artboards[a].name);
            var miss = missingLinks(d0);
            if (miss.length) warnings.push(miss.length + " linked images are missing and may come out blank: " + miss.join(", ") + ". Relink (Links panel) or Embed them and run again.");
            d0.close(SaveOptions.DONOTSAVECHANGES);

            var multi = abNames.length > 1;
            for (var i = 0; i < abNames.length; i++) {
                var d = app.open(tmp);
                var st = prepArtboard(d, i, opts, warnings);
                var texts = opts.writeJson ? collectTexts(d) : [];

                var outName = baseName(src) + (multi ? "_" + pad(i + 1) + "_" + fileSafe(abNames[i]) : "_AE") + ".ai";
                var f = new File(outFolder.fsName + "/" + outName);
                var so = new IllustratorSaveOptions();
                so.pdfCompatible = true;      
                so.compressed = true;
                so.embedICCProfile = false;
                so.saveMultipleArtboards = false;
                d.saveAs(f, so);
                outFiles.push(f);
                d.close(SaveOptions.DONOTSAVECHANGES);

                if (opts.writeJson) {
                    if (texts.length) { st.textsOk = 0; for (var ti = 0; ti < texts.length; ti++) if (texts[ti].convert) st.textsOk++; st.textsAll = texts.length; }
                    var jw = safe(function () { return writeSidecar(f, texts); }, null);
                    if (!jw) warnings.push(outName + ": .text.json was not written (folder permissions?).");
                }

                var extra = [];
                if (st.offArtboard) extra.push(st.offArtboard + " outside the artboard");
                if (st.hidden) extra.push(st.hidden + " hidden");
                if (st.hiddenLayers) extra.push(st.hiddenLayers + " hidden layers");
                if (st.guides) extra.push(st.guides + " guides");
                if (st.stray) extra.push(st.stray + " stray points");
                if (st.emptyText) extra.push(st.emptyText + " empty text");
                var clipInfo = [];
                if (st.clipReleased) clipInfo.push(st.clipReleased + " artboard masks removed");
                if (st.clipMatte) clipInfo.push(st.clipMatte + " masks as content + matte (M1, M2…)");
                if (st.padX || st.padY) clipInfo.push("artboard +" + st.padX + "/+" + st.padY + " px → comp " + st.compW + "x" + st.compH +
                    " (frame " + st.frameW + "x" + st.frameH + ": hidden layer FRAME)");
                lines.push("• " + outName + "  →  " + st.layers + " layers" +
                    (st.blended ? ", " + st.blended + " with a blend mode (mode in the name, set it in AE)" : "") +
                    (st.txtAlone ? ", " + st.txtAlone + " live text layers" : "") +
                    (clipInfo.length ? "\n     " + clipInfo.join(", ") : "") +
                    (opts.writeJson && st.textsAll ? ", " + st.textsAll + " in .text.json (" + st.textsOk + " → text layers)" : "") +
                    (extra.length ? "\n     deleted: " + extra.join(", ") : ""));
            }
        } finally {
            app.userInteractionLevel = prevUIL;
            if (prevCS !== null) safe(function () { app.coordinateSystem = prevCS; });
            safe(function () { tmp.remove(); });
        }

        var msg = "Done! " + lines.length + " files in the folder:\n" + outFolder.fsName + "\n\n" + lines.join("\n");
        if (warnings.length) msg += "\n\nCheck:\n- " + warnings.join("\n- ");
        return { message: msg, files: lines.length, outFiles: outFiles, warnings: warnings, outFolder: outFolder };
    }

    $.global.AI2AE = { processFile: processFile, version: VERSION };
    if ($.global.AI2AE_NO_UI) return;

    function main() {
        if (app.documents.length === 0) {
            alert("Open the storyboard in Illustrator first.", SCRIPT_NAME);
            return;
        }
        var doc = app.activeDocument;
        var src = safe(function () { return doc.fullName; }, null);
        if (!src || !src.exists) {
            alert("Save the file first. The script works on a copy of the saved file.", SCRIPT_NAME);
            return;
        }
        if (!doc.saved && !confirm("The file has unsaved changes. The last saved version will be used. Continue?")) {
            return;
        }
        var miss = missingLinks(doc);
        if (miss.length && !confirm("Missing: " + miss.length + " linked images:\n" + miss.slice(0, 8).join("\n") +
            (miss.length > 8 ? "\n…" : "") + "\n\nThey may come out blank in the AE files. Relink or Embed them first.\nContinue anyway?")) {
            return;
        }
        var opts = showDialog(doc, src);
        if (!opts) return;

        try {
            var res = processFile(src, opts);
            alert(res.message, SCRIPT_NAME);
            if (opts.openResults && res.outFiles.length) {

                for (var k = res.outFiles.length - 1; k >= 0; k--) {
                    var ff = res.outFiles[k];
                    safe(function () { app.open(ff); });
                }
            } else {
                safe(function () { res.outFolder.execute(); }); 
            }
        } catch (e) {
            alert("Error: " + e.message + (e.line ? " (line " + e.line + ")" : ""), SCRIPT_NAME, true);
        }
    }

    main();
})();
